import java.rmi.*;
public interface AddServerIntf extends Remote {
double add(double d1, double d2) throws RemoteException;

 double sub(double d1,double d2) throws RemoteException;  

 double mul(double d1,double d2) throws RemoteException;  

 double div(double d1,double d2) throws RemoteException;  

 double mod(double d1,double d2) throws RemoteException;  

}



